!!! THE ZINGCHART NAMING CONVENTION HAS CHANGED AS OF VERSION 2.0.5 (JANUARY 13TH, 2015) !!!

The primary script is now named zingchart.min.js

Modules use the following format zingchart-*.min.js

IT IS CRITICAL THAT YOU UPDATE YOUR SCRIPT ELEMENT URI'S TO REFLECT THESE CHANGES!

```
<script src="path/to/zingchart.min.js"></script>
<script>zingchart.MODULESDIR="path/to/modules/</script>
```
